package com.files.services.exceptions;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.files.services.dto.ErrorResponse;

@RestControllerAdvice
public class ServiceExceptionHandler extends ResponseEntityExceptionHandler {

	private ResponseEntity<ErrorResponse> sendResponse(WebRequest request, Exception ex, HttpStatus httpStatus) {
		ErrorResponse errorRecord = new ErrorResponse(ex.getMessage(), Instant.now().toString(),
				request.getDescription(Boolean.FALSE));
		return ResponseEntity.status(httpStatus).body(errorRecord);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> handleAllExceptions(WebRequest request, Exception ex) {
		ex.printStackTrace();
		return sendResponse(request, ex, HttpStatus.INTERNAL_SERVER_ERROR);
	}



}
