package com.files.services.dto;

public class ErrorResponse {

	private String error;
	private String date;
	private String description;

	public ErrorResponse() {
	}

	public ErrorResponse(String error, String date, String description) {
		this.error = error;
		this.date = date;
		this.description = description;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		date = date;
	}

}
