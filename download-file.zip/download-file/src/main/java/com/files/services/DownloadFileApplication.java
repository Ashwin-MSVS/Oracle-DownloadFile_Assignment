package com.files.services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class DownloadFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(DownloadFileApplication.class, args);
	}

}
