package com.files.services.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FilesService {


	public InputStreamResource getFile() throws IOException {

		File file = new File("./files/abcd.txt");
		return new InputStreamResource(new FileInputStream(file));
	}
}
