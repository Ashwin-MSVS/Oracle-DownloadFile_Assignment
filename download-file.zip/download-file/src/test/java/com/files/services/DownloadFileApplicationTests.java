package com.files.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DownloadFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
